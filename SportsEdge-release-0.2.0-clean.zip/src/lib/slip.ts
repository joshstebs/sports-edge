import type { ChatMessage, SgpLeg } from '../types';
import { legKey } from './odds';

const MAX_SAVED_LEGS = 200;

function optionalText(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function optionalNumber(value: unknown): number | undefined {
  if (value === null || value === undefined || value === '') return undefined;
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

/** Validate and normalize the model-generated payload before it reaches React. */
export function normalizeSgpLeg(value: unknown): SgpLeg | null {
  if (!value || typeof value !== 'object') return null;
  const raw = value as Record<string, unknown>;
  const selection = optionalText(raw.selection);
  if (!selection) return null;

  const line =
    typeof raw.line === 'string' || typeof raw.line === 'number' || raw.line === null
      ? raw.line
      : undefined;
  const odds = optionalNumber(raw.odds);
  const confidence = optionalNumber(raw.confidence);
  const gameOdds =
    typeof raw.game_odds === 'string' || typeof raw.game_odds === 'number'
      ? String(raw.game_odds).trim() || undefined
      : undefined;

  return {
    sport: optionalText(raw.sport),
    game: optionalText(raw.game),
    selection,
    market: optionalText(raw.market),
    line,
    odds: odds === undefined ? null : odds,
    justification: optionalText(raw.justification),
    risk: optionalText(raw.risk),
    correlation: optionalText(raw.correlation),
    confidence:
      confidence === undefined ? undefined : Math.max(0, Math.min(100, confidence)),
    game_odds: gameOdds ?? null,
  };
}

/**
 * Append new recommendations while refreshing an already-present wager in
 * place. Functional state updates can call this repeatedly without losing a
 * prior SSE event or producing duplicate slip rows.
 */
export function mergeSgpLegs(previous: readonly SgpLeg[], incoming: readonly unknown[]): SgpLeg[] {
  const byIdentity = new Map<string, SgpLeg>();

  for (const raw of [...previous, ...incoming]) {
    const leg = normalizeSgpLeg(raw);
    if (!leg) continue;
    const identity = legKey(leg);
    const current = byIdentity.get(identity);
    byIdentity.set(identity, current ? { ...current, ...leg } : leg);
  }

  return Array.from(byIdentity.values()).slice(-MAX_SAVED_LEGS);
}

/** Seed the standalone slip when upgrading a session created by the old UI. */
export function collectMessageLegs(messages: readonly ChatMessage[]): SgpLeg[] {
  let legs: SgpLeg[] = [];
  for (const message of messages) {
    if (message.role === 'assistant' && Array.isArray(message.sgp)) {
      legs = mergeSgpLegs(legs, message.sgp);
    }
  }
  return legs;
}

function localDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/** One wager may be tracked once per local game day. */
export function ledgerLegKey(leg: SgpLeg, date = new Date()): string {
  return `${localDateKey(date)}::${legKey(leg)}`;
}

/** Deterministic FNV-1a ticket key: stable across retries, compact in storage. */
export function ledgerTicketKey(legs: readonly SgpLeg[], date = new Date()): string {
  const identity = legs
    .map((leg) => ledgerLegKey(leg, date))
    .sort()
    .join('|');
  let hash = 0x811c9dc5;
  for (let i = 0; i < identity.length; i += 1) {
    hash ^= identity.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return `sports-edge-${localDateKey(date)}-${(hash >>> 0).toString(36)}`;
}
