export interface HealthInfo {
  ok: boolean;
  llmConfigured?: boolean;
  llmProvider?: string | null;
  sources?: Record<string, unknown>;
  version?: string;
}

/** GET /api/health — drives the "Live data" dot in the header. */
export async function fetchHealth(): Promise<HealthInfo> {
  const res = await fetch(`${import.meta.env.BASE_URL}api/health`, { headers: { Accept: 'application/json' } });
  if (!res.ok) {
    throw new Error(`Health check returned HTTP ${res.status}`);
  }
  return (await res.json()) as HealthInfo;
}

export interface SaveLedgerResponse {
  ok: boolean;
  duplicate?: boolean;
  added?: number;
  picks?: unknown[];
  summary?: unknown;
}

/** POST a ticket to the tracked-picks ledger with retry-safe idempotency. */
export async function saveLedgerTicket(
  legs: readonly unknown[],
  idempotencyKey: string,
): Promise<SaveLedgerResponse> {
  const res = await fetch(`${import.meta.env.BASE_URL}api/ledger`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'Idempotency-Key': idempotencyKey,
    },
    body: JSON.stringify({ legs, idempotencyKey }),
  });

  const payload = (await res.json().catch(() => null)) as
    | (Partial<SaveLedgerResponse> & { error?: string })
    | null;
  if (!res.ok || !payload?.ok) {
    throw new Error(payload?.error || `Could not track bet (HTTP ${res.status})`);
  }
  return payload as SaveLedgerResponse;
}
