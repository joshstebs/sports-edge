// SportsEdge Express app (framework-agnostic — used by the local listener AND
// the Vercel serverless function via api/index.ts).

import express, { NextFunction, Request, Response } from 'express';
import rateLimit, { ipKeyGenerator } from 'express-rate-limit';
import {
  authenticateRequest,
  createAuthRouter,
  loadAuthConfig,
  requireAuth,
} from './auth/index.js';
import { chatRouter } from './routes/chat.js';
import { healthRouter } from './routes/health.js';
import { ledgerRouter } from './routes/ledger.js';
import { evaluationRouter, predictionsRouter } from './routes/predictions.js';

const app = express();
// Vercel terminates TLS and forwards the real client IP. Trust exactly that
// first proxy hop so per-IP rate limiting does not collapse every visitor into
// the same bucket (or reject X-Forwarded-For as an unexpected header).
app.set('trust proxy', process.env.VERCEL ? 1 : false);
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  if (process.env.VERCEL || process.env.NODE_ENV === 'production') {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }
  const mutating = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
  const fetchSite = req.get('sec-fetch-site');
  const expectedOrigin = process.env.APP_ORIGIN?.replace(/\/$/, '');
  const origin = req.get('origin')?.replace(/\/$/, '');
  if (mutating && ((fetchSite && fetchSite !== 'same-origin') || (expectedOrigin && origin && origin !== expectedOrigin))) {
    res.status(403).json({ ok: false, error: 'Cross-origin request rejected.' });
    return;
  }
  next();
});
const authConfig = loadAuthConfig();

// Public deployment guard: cap per-IP abuse (LLM quota burn, ledger spam).
// This is best-effort per instance; use Vercel Firewall rate limits as the
// distributed production boundary when the project receives public traffic.
const chatLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.auth?.userId ? `user:${req.auth.userId}` : `ip:${ipKeyGenerator(req.ip ?? '')}`,
  message: { ok: false, error: 'Rate limit reached — try again in a few minutes.' },
});
const writeLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.auth?.userId ? `user:${req.auth.userId}` : `ip:${ipKeyGenerator(req.ip ?? '')}`,
  message: { ok: false, error: 'Rate limit reached — try again in a few minutes.' },
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: true,
  message: { ok: false, error: 'Too many sign-in attempts. Try again later.' },
});

// Parse the public login body under a much smaller limit before the larger
// screenshot-capable chat parser. Form bodies are intentionally unsupported.
app.use('/api/auth/login', authLimiter, express.json({ limit: '8kb', type: 'application/json' }));
app.use(express.json({ limit: '12mb', type: 'application/json' })); // attached screenshots (data URLs)
app.use('/api', createAuthRouter(authConfig));
app.use(authenticateRequest(authConfig));
app.use('/api/chat', chatLimiter);
app.use('/api/ledger', writeLimiter);
app.use('/api/predictions', writeLimiter);
app.use('/api', healthRouter);
app.use('/api', evaluationRouter);
app.use('/api', requireAuth, chatRouter);
app.use('/api', requireAuth, ledgerRouter);
app.use('/api', requireAuth, predictionsRouter);

app.get('/', (_req, res) => {
  res.json({ name: 'sports-edge-server', version: '0.2.0', endpoints: ['/api/health', '/api/sources', '/api/auth/session', '/api/chat', '/api/ledger', '/api/predictions'] });
});

// Never crash on provider/LLM failures — log the full error server-side,
// return a generic message to the client (no internal path/stack leakage).
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error('[server error]', err.message);
  if (res.headersSent) {
    res.end();
    return;
  }
  res.status(500).json({ ok: false, error: 'internal error' });
});

export default app;
