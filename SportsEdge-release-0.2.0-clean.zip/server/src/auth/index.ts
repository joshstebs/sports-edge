export { loadAuthConfig, type AuthConfig, type AuthUser } from './config.js';
export { authenticateRequest, requireAuth, requireRole } from './middleware.js';
export { hashPassword, verifyPassword } from './password.js';
export { createAuthRouter } from './router.js';
export {
  AUTH_COOKIE_NAME,
  createSessionToken,
  verifySessionToken,
  type AuthRole,
  type AuthSession,
} from './session.js';
